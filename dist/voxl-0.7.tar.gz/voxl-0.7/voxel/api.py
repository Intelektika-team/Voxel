import voxel.cli as c
import voxel.lang as l

version = c.ver_str


class API:
    def api():
        c.__main__()
    def getlang():
        return l
